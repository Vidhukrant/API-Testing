package assertions;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import utility.PropertyReader;
import utility.SnapShots;

public class ValidationsCheck {
	
	
	public static void TravelMessageShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
		
		
		Thread.sleep(3000);
		
		String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("DestinationField"))).getText();
		System.out.println(s);
		
		if(s.trim().equalsIgnoreCase(expValidation))
		{
			t1.log(LogStatus.PASS, "Travel validation message met when user proceed the quote without entering country");
		    report.endTest(t1);
		    
			Assert.assertTrue(true);
			
		}
		else
		{
			t1.log(LogStatus.FAIL, "Validation Message not met with expected validation message");
		    report.endTest(t1);
		    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message");
			Assert.assertTrue(false);
	         
		}
	}
	
	
	public static void WarningMessageWithDomesticAndInternationalShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
		
		String CheckValidation= driver.findElement(By.xpath(PropertyReader.getValidationMessage("DomesticInternationalMessage"))).getText();
		
		if(CheckValidation.trim().equalsIgnoreCase(expValidation))
		{
			t1.log(LogStatus.PASS, "Travel validation message met when user enter national and international country together");
		    report.endTest(t1);
		    
			Assert.assertTrue(true);
			
		}
		else
		{
			t1.log(LogStatus.FAIL, "Domestic and international country ");
		    report.endTest(t1);
		    SnapShots.takeScreenshot(driver, "Wrong warning message displayed");
			Assert.assertTrue(false);
	         
		}
	
	}
	
	
public static void BlankLeavingDate(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
		
		String CheckValidation= driver.findElement(By.xpath(PropertyReader.getValidationMessage("LeavingDate"))).getText();
		
		if(CheckValidation.trim().equalsIgnoreCase(expValidation))
		{
			t1.log(LogStatus.PASS, "Leaving Date warning message met with expected warning message");
		    report.endTest(t1);
		    
			Assert.assertTrue(true);
			
		}
		else
		{
			t1.log(LogStatus.FAIL, "Domestic and international country ");
		    report.endTest(t1);
		    SnapShots.takeScreenshot(driver, "Wrong warning message displayed for blank leaving date");
			Assert.assertTrue(false);
	         
		}
	
	}

public static void BlankReturnDate(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	String CheckValidation= driver.findElement(By.xpath(PropertyReader.getValidationMessage("ReturnDate"))).getText();
	
	if(CheckValidation.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Leaving Date warning message met with expected warning message");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Domestic and international country ");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Wrong warning message displayed for blank return date");
		Assert.assertTrue(false);
         
	}

}

public static void PastTravelDate(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	String CheckValidation= driver.findElement(By.xpath(PropertyReader.getValidationMessage("PastDate"))).getText();
	
	if(CheckValidation.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Validation message showing correctly for past date");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Domestic and international country ");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Wrong warning message displayed for past travel date");
		Assert.assertTrue(false);
         
	}

}

public static void FutureDateWithMoreThan548Days(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	String CheckValidation= driver.findElement(By.xpath(PropertyReader.getValidationMessage("MoreThan548Days"))).getText();
	
	if(CheckValidation.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Validation message showing correctly for more than 548 days");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Domestic and international country ");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Wrong warning message displayed for more than 548 travel days");
		Assert.assertTrue(false);
         
	}

}


public static void PrimaryAgeValidation(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	String CheckValidation= driver.findElement(By.xpath(PropertyReader.getValidationMessage("PrimaryAge"))).getText();
	
	if(CheckValidation.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Validation message showing correctly for primary age");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Domestic and international country ");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Wrong validation message showing correctly for primary age");
		Assert.assertTrue(false);
         
	}

}


public static void PrimaryAgeBelow18(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	String CheckValidation= driver.findElement(By.xpath(PropertyReader.getValidationMessage("Below18Year"))).getText();
	
	if(CheckValidation.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Validation message showing correctly for less than 18 yr primary age");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Domestic and international country ");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Wrong validation message showing correctly for less than 18 yr primary age");
		Assert.assertTrue(false);
         
	}

}
public static void StateValidation(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	String CheckValidation= driver.findElement(By.xpath(PropertyReader.getValidationMessage("StateValidation"))).getText();
	
	if(CheckValidation.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Validation message showing correctly if user leave it as blank");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Domestic and international country ");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Wrong validation message showing correctly if user leave it as blank");
		Assert.assertTrue(false);
         
	}

}
	
	
}
	
	


