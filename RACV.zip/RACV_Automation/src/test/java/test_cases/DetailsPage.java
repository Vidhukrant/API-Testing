package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.DetailPage_Validations;
import base.InitiateDriver;
import pom.DetailsPageValidations;

public class DetailsPage extends InitiateDriver{
	
	@Test
	public void TC_007() throws InterruptedException, IOException {
		ExtentTest t1 = report.startTest("Details Page Validations");
		DetailsPageValidations object=new DetailsPageValidations(driver);
		object.details_page_validations();
		DetailPage_Validations.FNameShouldBe(driver, "Please enter the First Name of the Primary Traveler", report, t1);
		DetailPage_Validations.LNameShouldBe(driver, "Please enter the Last Name of the Primary Traveler", report, t1);
		DetailPage_Validations.DOBShouldBe(driver, "Please enter date of birth.", report, t1);
		DetailPage_Validations.AddressShouldBe(driver, "Please enter the Street Address", report, t1);
		DetailPage_Validations.SubrbShouldBe(driver, "Please enter the Suburb", report, t1);
		//DetailPage_Validations.StateShouldBe(driver, "Please select the State you reside in", report, t1);
		DetailPage_Validations.PostCodeShouldBe(driver, "Please enter the Postcode", report, t1);
		DetailPage_Validations.EmailAddShouldBe(driver, "Please enter the Email Address", report, t1);
		DetailPage_Validations.CnfEmailAddShouldBe(driver, "Please enter the Confirm Email Address", report, t1);
		DetailPage_Validations.PhoneShouldBe(driver, "Please1 enter a valid Phone number", report, t1);
	}

}
