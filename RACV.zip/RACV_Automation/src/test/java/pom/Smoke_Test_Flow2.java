package pom;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import assertions.ValidatePage;
import utility.PropertyReader;
import utility.SnapShots;

public class Smoke_Test_Flow2 {
	
	WebDriver driver=null;
	
	public Smoke_Test_Flow2(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void TC_002() throws IOException{
		
try {
			
			
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			JavascriptExecutor js=(JavascriptExecutor) driver;
			WebElement ele=driver.findElement(By.id("country"));
			
			//js.executeScript("arguments[0].scrollIntoView();", ele);
			js.executeScript("window.scrollBy(0,400)");
			Thread.sleep(6000);
			WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
			contry.click();
			Thread.sleep(2000);
			contry.sendKeys(PropertyReader.getElementLocator2("Country_Name"));
			
			Thread.sleep(2000);
			WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
			Con_Click.click();
			
			WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator2("Travel_Date")));
			
			Thread.sleep(2000);
			Date.sendKeys(PropertyReader.getElementLocator2("Date"));
					
			Actions act=new Actions(driver);
			act.click();
			
			WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator2("Age_First")));
			F_Age.sendKeys(PropertyReader.getElementLocator2("Age1"));
			Thread.sleep(2000);
			WebElement state_click=driver.findElement(By.xpath(PropertyReader.getElementLocator2("State")));
			state_click.click();
			
			Thread.sleep(2000);
			WebElement state=driver.findElement(By.xpath(PropertyReader.getElementLocator2("State_Choose")));
			state.click();
			Thread.sleep(2000);
			
			WebElement RACV=driver.findElement(By.xpath(PropertyReader.getElementLocator2("RACV")));
			RACV.click();
			Thread.sleep(2000);
			WebElement RACV_Mem= driver.findElement(By.xpath(PropertyReader.getElementLocator2("RACV_Member")));
			RACV_Mem.click();
			Thread.sleep(2000);
			WebElement Get_Quote=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Get_Quote")));
			Get_Quote.click();
			
			Thread.sleep(3000);
			js.executeScript("window.scrollBy(0,700)");
			Thread.sleep(60000);
			WebElement conti=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Continue")));
			conti.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			
			//Thread.sleep(000);
			js.executeScript("window.scrollBy(0,300)");
			
			Thread.sleep(1000);
			WebElement Pname=driver.findElement(By.id(PropertyReader.getElementLocator2("First_Name")));
			Pname.sendKeys(PropertyReader.getElementLocator2("Pfirst"));
			
			Thread.sleep(1000);
			WebElement Lname=driver.findElement(By.id(PropertyReader.getElementLocator2("Last_Name")));
			Lname.sendKeys(PropertyReader.getElementLocator2("Lfirst"));
			
			Thread.sleep(1000);
			WebElement DOB=driver.findElement(By.id(PropertyReader.getElementLocator2("Primary_DOB")));
			DOB.sendKeys(PropertyReader.getElementLocator2("DOB"));
			
			Thread.sleep(1000);
			WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
			address.sendKeys(PropertyReader.getElementLocator2("address"));
			
			Thread.sleep(3000);
			WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
			sub.sendKeys(PropertyReader.getElementLocator2("sub"));
			
			Thread.sleep(1000);
			WebElement state2=driver.findElement(By.xpath(PropertyReader.getElementLocator2("state2")));
			state2.click();
			
			Thread.sleep(1000);
			WebElement Choose_state2=driver.findElement(By.xpath(PropertyReader.getElementLocator2("select_state")));
			Choose_state2.click();
			
			Thread.sleep(1000);
			WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator2("Post_Code")));
			Post.sendKeys(PropertyReader.getElementLocator2("ZIP_Code"));
			
			Thread.sleep(1000);
			WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator2("Email")));
			email.sendKeys(PropertyReader.getElementLocator2("E_address"));
			
			Thread.sleep(1000);
			WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator2("Con_Email")));
			con_email.sendKeys(PropertyReader.getElementLocator2("con_address"));
			
			Thread.sleep(1000);
			WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator2("Phone")));
			Phone.sendKeys(PropertyReader.getElementLocator2("number"));
			
			 js.executeScript("window.scrollBy(0,900)");
			 
			 Thread.sleep(3000);
			 WebElement Yes_001=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Yes_001")));
			 Yes_001.click();
			 
			 Thread.sleep(2000);
			 WebElement Confirm_Finalise=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Confirm&Finalise")));
			 Confirm_Finalise.click();
			 Thread.sleep(5000);
			 js.executeScript("window.scrollBy(0,250)");
			 
			 Thread.sleep(2000);
			 WebElement YesonDetail=driver.findElement(By.xpath(PropertyReader.getElementLocator2("YesonDetail")));
			 YesonDetail.click();
			 Thread.sleep(2000);
			 
			 WebElement Assess=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Assess")));
			 Assess.click();
			 
			 
			 Thread.sleep(4000);
			 js.executeScript("window.scrollBy(0,250)");
			 
			 Thread.sleep(2000);
			 WebElement No1=driver.findElement(By.xpath(PropertyReader.getElementLocator2("No1")));
			 No1.click();
			 
			 Thread.sleep(2000);
			 WebElement No2=driver.findElement(By.xpath(PropertyReader.getElementLocator2("No2")));
			 No2.click();
			 
			 Thread.sleep(2000);
			 WebElement No3=driver.findElement(By.xpath(PropertyReader.getElementLocator2("No3")));
			 No3.click();
			 
			 Thread.sleep(2000);
			 js.executeScript("window.scrollBy(0,250)");
			 
			 Thread.sleep(2000);
			 WebElement Yes4=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Yes4")));
			 Yes4.click();
			 
			 js.executeScript("window.scrollBy(0,250)");
			 Thread.sleep(2000);
			 WebElement continue11=driver.findElement(By.xpath(PropertyReader.getElementLocator2("continue11")));
			 continue11.click();
			 
			 Thread.sleep(12000);
			 WebElement condition= driver.findElement(By.xpath(PropertyReader.getElementLocator2("condition")));
			 condition.sendKeys(PropertyReader.getElementLocator2("condition_value"));
			 
			 driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			 WebElement Diabetes= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Diabetes")));
			 Diabetes.click();
			 
			 Thread.sleep(3000);
			
			 
			 
			 WebElement start_declaration=driver.findElement(By.xpath(PropertyReader.getElementLocator2("start_declaration")));
			 js.executeScript("arguments[0].scrollIntoView();", start_declaration);

			 
			 Thread.sleep(2000);
			 
			 start_declaration.click();
			 
			 Thread.sleep(3000);
			 WebElement No_diab=driver.findElement(By.xpath(PropertyReader.getElementLocator2("No_diab")));
			 No_diab.click();
			 
			 Thread.sleep(3000);
			 WebElement Zero=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Zero")));
			 Zero.click();
			 
			 Thread.sleep(2000);
			 WebElement continue_medical= driver.findElement(By.xpath(PropertyReader.getElementLocator2("continue_medical")));
			 continue_medical.click();
			 
			 Thread.sleep(2000);
			 WebElement complete_declaration= driver.findElement(By.xpath(PropertyReader.getElementLocator2("complete_declaration")));
			 complete_declaration.click();
			 
			 
			 driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			 js.executeScript("window.scrollBy(0,500)");
			 WebElement AcceptMedical=driver.findElement(By.xpath(PropertyReader.getElementLocator2("AcceptMedical")));
			 AcceptMedical.click();
		     Thread.sleep(20000);
		     js.executeScript("window.scrollBy(0,400)");
		     
		     Thread.sleep(2000);
		     WebElement Cntinue=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Cntinue")));
		     Cntinue.click();
		     
		     Thread.sleep(10000);
		     js.executeScript("window.scrollBy(0,500)");
		     
		     WebElement Yes1payment=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Yes1payment")));
		     Yes1payment.click();
		     
		     Thread.sleep(2000);
		     WebElement Yes2payment=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Yes2payment")));
		     Yes2payment.click();
		     
		     js.executeScript("window.scrollBy(0,500)");
		     
		     WebElement Card_Holder_Name=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Card_Holder_Name")));
		     Card_Holder_Name.sendKeys(PropertyReader.getElementLocator2("Name"));
		     
		     Thread.sleep(2000);
		     
             new WebDriverWait(driver, 20).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector("iframe#braintree-hosted-field-number[src*='hosted-fields-frame']")));
             WebElement cardnumber=driver.findElement(By.xpath(PropertyReader.getElementLocator2("CC_Number")));
             cardnumber.sendKeys(PropertyReader.getElementLocator2("Card_Num"));
             driver.switchTo().defaultContent();
             
             Thread.sleep(3000);
             
             new WebDriverWait(driver, 20).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector("iframe#braintree-hosted-field-expirationDate[src*='hosted-fields-frame']")));
             WebElement expirationdt=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Expiry_date")));
             expirationdt.sendKeys(PropertyReader.getElementLocator2("Exp_Date"));
             driver.switchTo().defaultContent();
             
             Thread.sleep(3000);
             new WebDriverWait(driver, 20).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector("iframe#braintree-hosted-field-cvv[src*='hosted-fields-frame']")));
             WebElement cvv=driver.findElement(By.xpath(PropertyReader.getElementLocator2("CVV")));
             cvv.sendKeys(PropertyReader.getElementLocator2("CVV_Num"));
             driver.switchTo().defaultContent();
             
             js.executeScript("window.scrollBy(0,300)");
             Thread.sleep(2000);
             WebElement Confirm_Pay=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Confirm_Pay")));
             Confirm_Pay.click();
             
             driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
             //ValidatePage.PageTitleShouldBe(driver, "Thank you for purchasing RACV Travel Insurance", report, t1);
		     
	}

catch(Exception e) {
	
	SnapShots.takeScreenshot(driver, "Fail1234");
	
}

}}
