package pom;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import base.InitiateDriver;
import utility.PropertyReader;
import utility.SnapShots;

public class PrimaryAdult {
	
	
	WebDriver driver=null;
	
	
	public PrimaryAdult(WebDriver driver) {
		
		this.driver=driver;
	}

	public void CheckPrimaryAge() throws IOException {
		try {
			WebElement contry=driver.findElement(By.id(PropertyReader.getValidationMessage("Country")));
			
		    JavascriptExecutor js=(JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)");
			Thread.sleep(4000);
			
			contry.click();
			Thread.sleep(2000);
			contry.sendKeys(PropertyReader.getValidationMessage("Country_Name"));
			
			Thread.sleep(2000);
			WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getValidationMessage("Country_click")));
			Con_Click.click();
		
		    WebElement date=driver.findElement(By.id(PropertyReader.getValidationMessage("Travel_Date")));
		    date.sendKeys(PropertyReader.getValidationMessage("Date"));
		    
		    Thread.sleep(2000);
			
		    WebElement state_click=driver.findElement(By.xpath(PropertyReader.getValidationMessage("State")));
			state_click.click();
			
			   Thread.sleep(2000);
			WebElement state=driver.findElement(By.xpath(PropertyReader.getValidationMessage("State_Choose")));
			   state.click();
			
		       Thread.sleep(2000);
			
			   WebElement RACV=driver.findElement(By.xpath(PropertyReader.getValidationMessage("RACV")));
			   RACV.click();
			   Thread.sleep(2000);
			   WebElement RACV_Mem= driver.findElement(By.xpath(PropertyReader.getValidationMessage("RACV_Member")));
			   RACV_Mem.click();
			   Thread.sleep(2000);
			   WebElement test=driver.findElement(By.xpath(PropertyReader.getValidationMessage("Get_Quote")));
			   test.click();
			
			
		}
		
		catch (Exception e) {
		
			System.out.println(e);
			SnapShots.takeScreenshot(driver, "Fail for primary age");
		}
	}
}
