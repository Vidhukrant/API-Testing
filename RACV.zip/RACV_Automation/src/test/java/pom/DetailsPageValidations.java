package pom;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utility.PropertyReader;

public class DetailsPageValidations {
	WebDriver driver=null;
	public DetailsPageValidations(WebDriver driver) {
		
		this.driver=driver;
		
		
	}
	public void details_page_validations() {
		
try {
			
			
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			JavascriptExecutor js=(JavascriptExecutor) driver;
			WebElement ele=driver.findElement(By.id("country"));
			
			//js.executeScript("arguments[0].scrollIntoView();", ele);
			js.executeScript("window.scrollBy(0,400)");
			Thread.sleep(6000);
			WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator("Country")));
			contry.click();
			Thread.sleep(2000);
			contry.sendKeys(PropertyReader.getElementLocator("Country_Name"));
			
			Thread.sleep(2000);
			WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator("Country_click")));
			Con_Click.click();
			
			WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator("Travel_Date")));
			
			Thread.sleep(2000);
			Date.sendKeys(PropertyReader.getElementLocator("Date"));
					
			Actions act=new Actions(driver);
			act.click();
			
			WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator("Age_First")));
			F_Age.sendKeys(PropertyReader.getElementLocator("Age1"));
			Thread.sleep(2000);
			WebElement state_click=driver.findElement(By.xpath(PropertyReader.getElementLocator("State")));
			state_click.click();
			
			Thread.sleep(2000);
			WebElement state=driver.findElement(By.xpath(PropertyReader.getElementLocator("State_Choose")));
			state.click();
			Thread.sleep(2000);
			
			WebElement RACV=driver.findElement(By.xpath(PropertyReader.getElementLocator("RACV")));
			RACV.click();
			Thread.sleep(2000);
			WebElement RACV_Mem= driver.findElement(By.xpath(PropertyReader.getElementLocator("RACV_Member")));
			RACV_Mem.click();
			Thread.sleep(2000);
			WebElement Get_Quote=driver.findElement(By.xpath(PropertyReader.getElementLocator("Get_Quote")));
			Get_Quote.click();
			
			Thread.sleep(3000);
			js.executeScript("window.scrollBy(0,700)");
			Thread.sleep(40000);
			WebElement conti=driver.findElement(By.xpath(PropertyReader.getElementLocator("Continue")));
			conti.click();
			js.executeScript("window.scrollBy(0,1000)");
			
			 Thread.sleep(2000);
			 WebElement no=driver.findElement(By.xpath(PropertyReader.getElementLocator("No")));
			 no.click();
			 js.executeScript("window.scrollBy(0,1000)");
			 Thread.sleep(1000);
			 WebElement cnf= driver.findElement(By.xpath(PropertyReader.getElementLocator("Confirm")));
			 cnf.click();
			 js.executeScript("window.scrollBy(0,250)");
	}

catch(Exception e) {

}}}
